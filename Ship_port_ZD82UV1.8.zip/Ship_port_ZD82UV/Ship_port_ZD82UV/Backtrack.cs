﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ship_port_ZD82UV
{
    //VisszaLépése keresés
    internal class Backtrack
    {
        //Benne van-e a matrixban és hajó nem null
        static bool ConditionOne(int col, int row, NewPort docks, Ship ship)
        {

            if (ship is null)
            {
                return false;
            }

            return 0 <= col && col < docks.col && 0 <= row && row < docks.row;

        }
        //Szabad helyek megvizsgálása és keresés
        static bool ConditionTwo(int col, int row, NewPort docks, Ship ship)
        {

            for (int i = 0; i < row + 1; i++)
            {
                int assistant = 0;

                for (int j = 0; j < docks.portMatrix.GetLength(1); j++)
                {


                    if (docks.portMatrix[i, j] == null)
                    {

                        assistant++;
                        if (assistant == ship.size)
                        {

                            int x = (i - assistant) + 1;
                            int y = (j - assistant) + 1;                            //+1
                            docks.Place(ship, i, y);

                            docks.ShipOnTheMove(ship);
                            //---------------------Teszteléshez használt kód rész-------------------------------------
                            //Console.WriteLine("Press Enter");
                            Console.ReadLine();




                            return true;
                        }

                    }

                }

            }

            return false;
        }


        public static void FindSolution(int level, ref bool found, NewPort docks)
        {
            int j = -1;
            while (!found && docks.waitingLineLL != null)
            {

                j++;  

                Console.Clear();
                docks.Show();
                System.Threading.Thread.Sleep(250);

                //VáróLista berakása
                Ship ship = docks.waitingLineLL.First() as Ship;
                if (ConditionOne(j, level, docks, ship )) 
                {

                    if (ConditionTwo(j, level, docks, ship) /*!= -1*/)
                    {
                        //Ha vége a listának álljon le 
                        if (ship is null)
                        {
                            found = true;

                        }
                        else
                        {
                            //Hajo törlése + Tovább lépés
                            docks.waitingLineLL.DeleteNode(ship.id);
                            ship = docks.waitingLineLL.First() as Ship;
                        }

                    }
                    else
                    {
                        //Sor növelése
                        FindSolution(level + 1, ref found, docks);
                    }

                }
                else
                    found = true;
                //vége

            }

        }
    }
}
