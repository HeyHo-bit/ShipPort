﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ship_port_ZD82UV
{
    //Generilikus LáncoltLista
    class LinkedList<T>
    {
        //ListaElem
        class Node<T>
        {
            public T Data;
            public Node<T> Next;

        }

        private Node<T> head;


        //Elore beileszt 
        public void InsertFront(T data)
        {
            Node<T> newNode = new Node<T>();
            newNode.Data = data;

            newNode.Next = head;
            head = newNode;
        }



        public void DeleteNode(string data)
        {
            Node<T> left = null;
            Node<T> right = head;

            while (right != null && ((right.Data as Ship).id) as string != data)
            {
                left = right;
                right = right.Next;
            }

            //Nem létezik
            if (right is null)
                return;

            //Elso elem törlése
            if (left is null)
                head = head.Next;
            else
                left.Next = right.Next;
        }

        //Tartalmaz-e
        public bool Contains(string id)
        {
            Node<T> temp = head;
            while (temp != null)
            {
                if ((temp.Data as Ship).id == id)
                    return true;
                temp = temp.Next;
            }
            return false;
        }


        //Keres
        public object Find(string id)
        {
            if (Contains(id))
            {
                Node<T> temp = head;
                while (temp != null)
                {
                    if ((temp.Data as Ship).id == id)
                        return temp.Data;
                    temp = temp.Next;
                }
            }
            return null;
        }


        //Elso
        public object First()
        {
            if (head == null)
                return null;
            return head.Data as Ship;
        }


        //Listázás
        public void List()
        {
            Node<T> temp = head;
            while (temp != null)
            {
                Console.WriteLine(((temp.Data) as Ship).id);
                temp = temp.Next;
            }
        }


        //----------------------------------------------------------------
        //Testeléshesz használt rész
        //----------------------------------------------------------------

        //class LinkedList
        //{

        //    class Node
        //    {
        //        public Ship Data;
        //        public Node Next;

        //    }

        //    private Node head;

        //    public void InsertFront(Ship data)
        //    {
        //        Node newNode = new Node();
        //        newNode.Data = data;

        //        newNode.Next = head;
        //        head = newNode;
        //    }

        //    public void DeleteNode(string data)
        //    {
        //        Node left = null;
        //        Node right = head;

        //        while (right != null && right.Data.id != data)
        //        {
        //            left = right;
        //            right = right.Next;
        //        }

        //        //non existing item
        //        if (right is null)
        //            return;

        //        //delete in case first item
        //        if (left is null)
        //            head = head.Next;
        //        else
        //            left.Next = right.Next;
        //    }

        //    public bool Contains(string id)
        //    {
        //        Node temp = head;
        //        while (temp != null)
        //        {
        //            if (temp.Data.id == id)
        //                return true;
        //            temp = temp.Next;
        //        }
        //        return false;
        //    }

        //    public Ship Find(string id)
        //    {
        //        if (Contains(id))
        //        {
        //            Node temp = head;
        //            while (temp != null)
        //            {
        //                if (temp.Data.id == id)
        //                    return temp.Data;
        //                temp = temp.Next;
        //            }
        //        }
        //        return null;
        //    }


        //    public void ListElements()
        //    {

        //        Node temp = head;
        //        while (temp != null)
        //        {
        //            Console.WriteLine(temp.Data.id);
        //            temp = temp.Next;
        //        }
        //    }
        //}

    }
}
