﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ship_port_ZD82UV
{

        enum Status { good, notStearable, wrecked }
        enum Orientation { horizontal, vertival }
        class Ship
        {
            static Random r = new Random();
            public string id { get; }

            //Pozicio a mátroxban -> bal felso "block" a kezdo pozico a hajonak 
            public int posA { get; set; }
            public int posB { get; set; }

            // Méret "blockokban" -> Kiszámitva a "counstructor"-ban
            public int sizeX { get; set; }
            public int sizeY { get; set; }
            public int size { get; }
            //Hajo szin counstructor-ban állítodik be
            public int color;

            //
            public Status status { get; }
            public Orientation orientation { get; set; }

            //Hajo méret adás counstructor
            public Ship(double widht, double length, Status shipoStatus, string id)
            {
                sizeX = CalculateSize(4, widht);
                sizeY = CalculateSize(8, length);
                size = sizeX * sizeY;
                status = shipoStatus;
                this.id = id;

                if (posB < posA)
                    orientation = Orientation.vertival;
                else
                    orientation = Orientation.horizontal;

                this.color = r.Next(1, 16);
            }

            ////Not upadted with main constructor
            ////public Ship(double widht, double length, Status shipoStatus)
            //{
            //    sizeX = CalculateSize(4, widht);
            //    sizeY = CalculateSize(8, length);
            //    size = sizeX * sizeY;
            //    status = shipoStatus;
            //    id = GenerateRandomID();

            //}

            // ---<------------------------------------------------>---

            //Adatok
            public void ShipInfo()
            {
                Console.WriteLine($"\n" +
                    $"------< ShipInfo >------\n" +
                    $"ID: {id} \n" +
                    $"sizeX: {sizeX}\n" +
                    $"sizeY: {sizeY}\n" +
                    $"Status: {status}\n" +
                    $"Orientation: {orientation}\n" +
                    $"------------------------\n");
            }



            //ID generálás -------------test
            private string GenerateRandomID()
            {
                string id = "";
                for (int i = 0; i < 4; i++)
                {
                    id += (r.Next(0, 10)).ToString();
                }
                return id;
            }


            //Kiszámolja a szukséges helyet, tableData a Port mátrixban egy hely, ShipData a halyó mérete
            private int CalculateSize(double tableData, double shipData)
            {
                int db = 0;
                while (shipData > 0)
                {
                    db++;
                    shipData -= tableData;
                }
                return db;
            }


            //Hajó forgatása
            public void RotateShip()
            {
                int temp = sizeX;
                sizeX = sizeY;
                sizeY = temp;
            }


            //Hajó tipus visszatérés
            public override string ToString()
            {
                if (this.status == Status.good)
                    return "████";
                else if (this.status == Status.notStearable)
                    return "▓▓▓▓";
                else if (this.status == Status.wrecked)
                    return "░░░░";
                return "????";
            }



        }
}

