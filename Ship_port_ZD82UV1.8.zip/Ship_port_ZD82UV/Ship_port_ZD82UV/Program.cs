﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Ship_port_ZD82UV
{
    internal class Program
    {
        static void Display(Ship ship)
        {
            string movesShips = " ";
            movesShips += ship.id + " ";
            Console.WriteLine($"Moved Ship: {movesShips}");

        }
        static void Main(string[] args)
        {
            //---------------------Teszteléshez használt kód rész-------------------------------------
            Ship s1 = new Ship(3.4, 7.6, Status.notStearable, "0001");
            Ship s2_1 = new Ship(4.4, 23.2, Status.good, "02_1");
            Ship s2_2 = new Ship(4.4, 23.2, Status.good, "02_2");
            Ship s2_3 = new Ship(4.4, 23.2, Status.wrecked, "02_3");
            Ship s2_4 = new Ship(4.4, 23.2, Status.good, "02_4");
            Ship s2_5 = new Ship(4.4, 23.2, Status.good, "02_5");
            Ship s3 = new Ship(4.4, 23.2, Status.good, "0003");

            Ship s1_1 = new Ship(3.4, 7.6, Status.notStearable, "01_1");
            Ship s1_2 = new Ship(3.4, 7.6, Status.notStearable, "01_2");

            //Port port = new Port(4, 8);



            NewPort newPort = new NewPort(4, 8);

            //---------------------Teszteléshez használt kód rész-------------------------------------
            //newPort.Place(s1,0,0);
            //newPort.Place(s2_1, 0, 1);
            //newPort.Place(s2_2, 0, 4);
            ////newPort.AddShip(s2_3);
            ////newPort.AddShip(s2_4);
            //newPort.Show();
            //Console.WriteLine(newPort.IsPlacabe(s2_3, 1, 0));

            //---------------------Teszteléshez használt kód rész-------------------------------------
            //newPort.AddToWaitingLine(s1_2);
            //newPort.AddToWaitingLine(s1_1);
            //newPort.AddToWaitingLine(s2_1);
            //newPort.AddToWaitingLine(s2_2);
            //newPort.AddToWaitingLine(s2_3);
            //newPort.AddToWaitingLine(s2_4);
            //newPort.AddToWaitingLine(s2_5);
            //newPort.AddToWaitingLine(s3);


            string[] lines = File.ReadAllLines(@"adat.txt");
            foreach (string line in lines)
            {
                string[] SplittedLine = line.Split();
                if (SplittedLine[0] == "Good")
                {
                    Ship ship = new Ship(double.Parse(SplittedLine[1]), double.Parse(SplittedLine[2]), Status.good, SplittedLine[3]);
                    newPort.AddToWaitingLine(ship);
                }
                else if (SplittedLine[0] == "notStearable")
                {
                    Ship ship = new Ship(double.Parse(SplittedLine[1]), double.Parse(SplittedLine[2]), Status.notStearable, SplittedLine[3]);
                    newPort.AddToWaitingLine(ship);
                }
                else
                {
                    Ship ship = new Ship(double.Parse(SplittedLine[1]), double.Parse(SplittedLine[2]), Status.wrecked, SplittedLine[3]);
                    newPort.AddToWaitingLine(ship);
                }

            }

            bool end = false;
            while (end != true)
            {
                Console.Clear();
                Console.WriteLine("Options\n\n1. Show Ship Data and Port\n2. Refill Port(Can be called first) /After use restrart might needed for ship infromation /\n3. Exit");
                Console.Write("Choose Option ");
                string opcio = Console.ReadLine();
                switch (opcio)
                {
                    case "1":
                        Console.Clear();
                        //try
                        //{
                        newPort.FillPort();

                        newPort.Show();

                        //}
                        //catch (Exception e )
                        //{

                        //    throw e;
                        //}
                        //newPort.FillPort();

                        //newPort.Show();

                        Console.WriteLine("Press Enter");
                        Console.ReadLine();
                        break;
                    case "2":
                        Console.Clear();

                        newPort.ShipOnTheMove += Display;

                        string[] lines2 = File.ReadAllLines(@"adat.txt");
                        foreach (string line in lines2)
                        {
                            string[] SplittedLine = line.Split();
                            if (SplittedLine[0] == "Good")
                            {
                                Ship uj = new Ship(double.Parse(SplittedLine[1]), double.Parse(SplittedLine[2]), Status.good, SplittedLine[3]);
                                newPort.AddToWaitingLine(uj);
                            }
                            else if (SplittedLine[0] == "notStearable")
                            {
                                Ship uj = new Ship(double.Parse(SplittedLine[1]), double.Parse(SplittedLine[2]), Status.notStearable, SplittedLine[3]);
                                newPort.AddToWaitingLine(uj);
                            }
                            else
                            {
                                Ship uj = new Ship(double.Parse(SplittedLine[1]), double.Parse(SplittedLine[2]), Status.wrecked, SplittedLine[3]);
                                newPort.AddToWaitingLine(uj);
                            }

                        }

                        newPort.ReFillDocks();
                        //newPort.Show();

                        Console.WriteLine("Press Enter");
                        Console.ReadLine();
                        break;
                    case "3":
                        end = true;
                        break;
                    default:
                        break;
                }

            }
            //---------------------Teszteléshez használt kód rész-------------------------------------
            //newPort.FillPort();

            //newPort.Show();



            newPort.waitingLineLL.List();


            ////for (int i = 0; i < 50; i++)
            ////{
            ////    newPort.AddShip(s2);

            ////    newPort.Show();
            ////    Console.ReadKey();
            ////}


            Console.ReadKey();
        }

    }
}
