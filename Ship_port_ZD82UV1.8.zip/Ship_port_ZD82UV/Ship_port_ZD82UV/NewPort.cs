﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ship_port_ZD82UV
{

    internal class NewPort
    {
        //Delegált + event
        public delegate void DocksEventHandler(Ship ship);
        public DocksEventHandler ShipOnTheMove;

        //Kikoto adatok
        public int row, col;
        int freeBlocks;
        LinkedList<Ship> shipsInPortLL = new LinkedList<Ship>();
        public LinkedList<Ship> waitingLineLL = new LinkedList<Ship>();
        public Ship[,] portMatrix;

        //Construktor
        public NewPort(int row, int col)
        {
            this.row = row;
            this.col = col;
            freeBlocks = row * col;
            portMatrix = new Ship[this.row, this.col];

        }

        // ---<------------------------------------------------>---

        //Hajo várólistára helyezés
        public void AddToWaitingLine(Ship ship)
        {
            if (!waitingLineLL.Contains(ship.id))
                this.waitingLineLL.InsertFront(ship);
            else
            {
                Console.WriteLine($"<WARNING:NewPort.AddToWaiteListLL> - unable to place item ID:{ship.id} already exists.");
                return;
            }

        }
        //----------------------------------------------------------------
        //Visszalépése keresés, kikoto új rendezése
        public void ReFillDocks()
        {
            Ship temp = waitingLineLL.First() as Ship;
            bool found = false;
            while (temp != null)
            {
                //ShipOnTheMove?.Invoke(temp);
                shipsInPortLL.First();
                Backtrack.FindSolution(0, ref found, this);
                if (shipsInPortLL.Contains(temp.id))
                {
                    waitingLineLL.DeleteNode(temp.id);
                }

                temp = waitingLineLL.First() as Ship;
            }
        }

        //----------------------------------------------------------------

        //Hajok betoltése a váró listárol
        public void FillPort()
        {
            Ship temp = waitingLineLL.First() as Ship;
            while (temp != null)
            {

                AddShip(temp);

                //Hozzá van-e adva sikeresen
                if (shipsInPortLL.Contains(temp.id))
                {
                    waitingLineLL.DeleteNode(temp.id);
                }
                else
                {
                    Console.WriteLine($"<ERROR: NewPort.FillPort> - unable to place item ID:{temp.id} -> NewPort.FillPort stops.");
                    return;
                }


                temp = waitingLineLL.First() as Ship;
            }

            if (temp == null)
            {
                Console.WriteLine($"<SUCCESS: NewPort.FillPort> - all ships are loaded to port");
                return;
            }
            else
            {
                Console.WriteLine($"<ERROR: NewPort.FillPort> - unable to place item ID:{temp.id} -> NewPort.FillPort stops.");
                return;
            }

        }



        //Egy hajo hozzá adása a kikotohöz
        public void AddShip(Ship ship)
        {
            //Hajo benne van-e
            if (shipsInPortLL.Contains(ship.id))
            {
                Console.WriteLine($"<WARNING: NewPort.AddShip> - unable to place item ID:{ship.id} already exists.");
                return;
            }

            //Van-e szabad hely
            if (this.freeBlocks < ship.size)
            {
                //Kivétel -> testhez használt
                //throw new UnableToPlaceException(ship,$"Unable to place not enought free space for ID {ship.id} :)");
                Console.WriteLine($"<WARNING: NewPort.AddShip> - not enaught free tiles for ID:{ship.id} - unable to place.");
                return;
            }

            //Hajo hozzáadása eredeti állásban
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    if (IsPlacabe(ship, i, j))
                    {
                        Place(ship, i, j);
                        Console.WriteLine($"<SUCCESS: NewPort.AddShip> - ID:{ship.id} added to {i},{j}");
                        ship.ShipInfo();
                        return;
                    }

                }
            }

            //Hajo forgatása ha lehetséges, 
            Console.WriteLine($"<INFO: NewPort.AddShip> - no continuous space for ID:{ship.id}, trying to rotate...");
            if (ship.status == Status.good)
            {
                ship.RotateShip();
                Console.WriteLine($"<INFO: NewPort.AddShip> - successfully rotated ID:{ship.id} ");
            }
            //Nem lehet a halyót elforgatni
            else
            {
                Console.WriteLine($"<WARNING: NewPort.AddShip> - unable to rotate item ID:{ship.id}.");
                return;
            }

            //Hajó forgatott hozzá adása
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    if (IsPlacabe(ship, i, j))
                    {
                        Place(ship, i, j);
                        Console.WriteLine($"<SUCCESS: NewPort.AddShip> - rotated ID:{ship.id} added to {i},{j}");
                        return;
                    }

                }
            }

            Console.WriteLine($"<WARNING: NewPort.AddShip> - failed to add rotated ID:{ship.id}");

        }


        //Hajo elhelyezése, (Szükséges, hogy IsPlacable igaz legyen) Elhyelezhető-e
        public void Place(Ship ship, int row, int col)
        {
            if (!IsPlacabe(ship, row, col))
            {
                Console.WriteLine($"<ERROR: NewPort.Place> - unable to place item ID:{ship.id}, NewPort.IsPlacable failed.");
                return;
            }

            ship.posA = row;
            ship.posB = col;
            this.freeBlocks -= ship.size;
            shipsInPortLL.InsertFront(ship);

            for (int i = 0; i < ship.sizeX; i++)
            {
                for (int j = 0; j < ship.sizeY; j++)
                {
                    portMatrix[ship.posA + i, ship.posB + j] = ship;
                }
            }

        }


        //Checks if ship is placabe to said tile(s)
        //Feltételek (Elhelyezhető-e a hajó adatt helyre)
        public bool IsPlacabe(Ship ship, int row, int col)
        {
            //Rossz bemenet -> mátrixon kivuli(row or col outside of matrix)
            if (row >= this.row || col >= this.col || row < 0 || col < 0)
                return false;
            //Van-e hely a kikotoben
            if (this.freeBlocks < ship.size)
                return false;
            //Foglalt-e
            if (portMatrix[row, col] != null)
                return false;
            //Tul nagy-e a hajo a helyhez(sor)
            if (row + ship.sizeX > this.row)
                return false;
            //Tul nagy-e a hajo a helyhez(oszlop)
            if (col + ship.sizeY > this.col)
                return false;
            //Szomszédos helyek nézése
            for (int i = 0; i < ship.sizeX; i++)
            {
                for (int j = 0; j < ship.sizeY; j++)
                {
                    if (portMatrix[row + i, col + j] != null)
                        return false;
                }
            }

            return true;
        }


        //Kikoto kiirása Consolra
        public void Show()
        {

            for (int i = 0; i < row; i++)
            {
                string temp = "";
                for (int j = 0; j < col; j++)
                {
                    if (portMatrix[i, j] != null)
                    {
                        Console.Write("[");
                        Console.ForegroundColor = (ConsoleColor)portMatrix[i, j].color;
                        Console.Write(portMatrix[i, j].ToString());
                        Console.ResetColor();
                        Console.Write("]");
                    }
                    else
                        Console.Write("[    ]");
                }
                Console.WriteLine(temp);
            }
            Console.WriteLine();
        }

        //Kivétel
        class UnableToPlaceException : Exception
        {
            public UnableToPlaceException(Ship sh, string message) : base(message)
            {

            }
        }

    }
}
