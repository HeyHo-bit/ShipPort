A fájl elérési uta amiből a program beolvas:

Ship_port_ZD82UV1.8.zip\Ship_port_ZD82UV\Ship_port_ZD82UV\bin\Debug\net5.0